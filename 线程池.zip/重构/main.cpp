#include "threadpool.h"
#include <iostream>
#include <future>
#include <memory>
#include <chrono>
using namespace std;
/*
example:
	int sum(int a,int b)
	{
		return a+b;
	}
	std::packaged_task<int(int, int)> task(sum);    
	std::future<int> res =  task.get_future();
	task(10,10);
	std::cout<<res<<endl;

	�����10+10

*/
//class mystask :public Task
//{
//public:
//	mystask() {}
//	void run()
//	{
//		//cout << "����task������,�̣߳���ʱ2s..." << endl;
//		std::this_thread::sleep_for(std::chrono::seconds(10));
//	}
//};
int sum1(int a, int b)
{

	std::this_thread::sleep_for(std::chrono::seconds(1));
	return a + b;
}
int main()
{

		ThreadPool threadpool;
		threadpool.setpoolMode(PoolMode::CACHE_MODE);
		threadpool.start(2);

		future<int> res = threadpool.submitTask(sum1, 1, 2);
		future<int> res1 = threadpool.submitTask(sum1, 1, 2);
		future<int> res2 = threadpool.submitTask(sum1, 1, 2);
		future<int> res3 = threadpool.submitTask(sum1, 1, 2);
		future<int> res42 = threadpool.submitTask(sum1, 1, 2);
		future<int> res4 = threadpool.submitTask(sum1, 1, 2);
		//cout << res.get()<<"******************************************" << endl;
		std::this_thread::sleep_for(std::chrono::seconds(20));



}


















//
//
//
//
//
//
//
//
//

//notEmpty_.notify_all();
//return result;