#include "threadpool.h"
#include <chrono>
#include <thread>
#include <iostream>


using ULong = unsigned long long;

class mytask :public Task
{
public:
    mytask(int a, int b)
        :begin_(a)
        , end_(b) {}

    Any run()
    {
        std::cout << "begin threadFunc tid:" << std::this_thread::get_id() << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(5));
        ULong res = 0;
        for (ULong i = begin_; i <= end_; i++)
        {
            res+=i;
        }
        std::cout << std::this_thread::get_id()<<":work done!" << std::endl;
        return res;
    }
private:
    int begin_;
    int end_;
};



int main()
{
    ThreadPool threadpool;
    threadpool.setMode_(PoolMode::MODE_CACHE);
    threadpool.start(4);

    Result res1 = threadpool.submitTask(std::make_shared<mytask>(1,100000000));
    Result res2  = threadpool.submitTask(std::make_shared<mytask>(100000001, 200000000));
    Result res3 = threadpool.submitTask(std::make_shared<mytask>(200000001, 300000000));
    threadpool.submitTask(std::make_shared<mytask>(200000001, 300000000));
    threadpool.submitTask(std::make_shared<mytask>(200000001, 300000000));
    threadpool.submitTask(std::make_shared<mytask>(200000001, 300000000));
    threadpool.submitTask(std::make_shared<mytask>(200000001, 300000000));
    threadpool.submitTask(std::make_shared<mytask>(200000001, 300000000));
    //ULong a= res1.get().cast_<ULong>();
    //ULong b = res2.get().cast_<ULong>();
    //ULong c = res3.get().cast_<ULong>();
    //std::cout << (a + b + c) << std::endl;
 

    //ULong sum = 0;
    //for (ULong i = 1; i <= 300000000; i++)
    //{
    //    sum += i;
    //}
    //std::cout << "��ȷ:" << sum << std::endl;
}