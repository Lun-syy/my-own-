#include <iostream>
#include <functional>
#include"threadpool.h"
#include <thread>
#include <condition_variable>
#include <queue>
#include <atomic>


const int MAX_TASK_THRESHOLD = 100;
const int MAX_THREAD_THRESHOLD = 10;
const int MAX_THREAD_LIVE_TIME = 10;

ThreadPool::ThreadPool()
    :initThreadsNum_(0)
    , tasksNum_(0)
    , taskMaxThreshold_(MAX_TASK_THRESHOLD)
    , poolMode_(PoolMode::MODE_FIX)
    , isRunning_(false)
    , threadNum_(0)
    , maxThreadNum_(MAX_THREAD_THRESHOLD)
    , idleThreadNum_(0)
{}
ThreadPool::~ThreadPool()
{
    isRunning_ = false;
    std::unique_lock<std::mutex> lock(mtx_);
    notEmpty_.notify_all();
    exit_.wait(lock, [&]()->bool {return threads_.size() == 0; });
}
void ThreadPool::start(size_t threadNum)
{
    if (checkRunning())
        return;
    isRunning_ = true;
    initThreadsNum_ = threadNum;
    threadNum_ = threadNum;
    for (int i = 0; i < initThreadsNum_; i++)
    {
        auto ptr = std::make_unique<Thread>(std::bind(&ThreadPool::threadFunc, this,std::placeholders::_1));
        int tid = ptr->getid();
        threads_.emplace(tid,std::move(ptr));
    }
    for (int i = 0; i < initThreadsNum_; i++)
    {
        threads_[i]->start();
        idleThreadNum_++;
    }

}
void ThreadPool::setTaskMaxNum(size_t num)
{
    if (checkRunning())
        return;
    taskMaxThreshold_ = num;
}

void ThreadPool::setThreadMaxThreshold(size_t num)
{
    if (checkRunning())
        return;
    if (poolMode_ == PoolMode::MODE_CACHE)
    {
        taskMaxThreshold_ = num;
    }
}
void ThreadPool::threadFunc(int tid)
{
    //��¼����ʱ��
    auto lasttime = std::chrono::high_resolution_clock().now();
    for (;;)
    {
        std::shared_ptr<Task> task;
        {
            std::unique_lock<std::mutex> lock(mtx_);
            std::cout << "tid:" << std::this_thread::get_id() << "���Ի�ȡ����...." << std::endl;
            while (tasksNum_ ==0 )
            {
                if (!isRunning_)
                {
                    threads_.erase(tid);
                    std::cout << "����ɾ���߳�:" << std::this_thread::get_id() << std::endl;
                    exit_.notify_all();
                    return;
                }
                if (poolMode_ == PoolMode::MODE_CACHE)
                {
                    if (std::cv_status::timeout == notEmpty_.wait_for(lock, std::chrono::seconds(1)))
                    {
                        auto now = std::chrono::high_resolution_clock().now();
                        auto dur = std::chrono::duration_cast<std::chrono::seconds>(now - lasttime);
                        if (dur.count()>= MAX_THREAD_LIVE_TIME && threadNum_>initThreadsNum_)
                        {
                            //�����߳�,��map��ɾ���߳�
                            threads_.erase(tid);
                            idleThreadNum_--;
                            threadNum_--;
                            std::cout << "ɾ���߳�" << std::this_thread::get_id() <<std::endl;
                            return;
                        }


                    }
                }
                else
                {
                    notEmpty_.wait(lock);
                }


            }
            idleThreadNum_--;
            std::cout << "tid:" << std::this_thread::get_id() << "��ȡ����ɹ�...." << std::endl;
            task = tasks_.front();
            tasks_.pop();
            tasksNum_--;
            if (tasks_.size() > 0)
            {
                notEmpty_.notify_all();
            }
            notFull_.notify_all();
        }
        if (task != nullptr)
        {
            task->myexe();
        }

        idleThreadNum_++;
        lasttime = std::chrono::high_resolution_clock().now();
    }


}


Result ThreadPool::submitTask(std::shared_ptr<Task> sp)
{
    std::unique_lock<std::mutex> lock(mtx_);
    if (!notFull_.wait_for(lock, std::chrono::seconds(2), [&]()->bool {return tasksNum_ < taskMaxThreshold_; }))
    {
        std::cerr << "queue is full!" << std::endl;
        return Result(sp,false);
    }
    tasks_.emplace(sp);
    tasksNum_++;
    notEmpty_.notify_all();

    if (poolMode_ == PoolMode::MODE_CACHE && tasksNum_> idleThreadNum_ && threadNum_<maxThreadNum_)
    {
        std::cout << "��������cached �������߳�" << std::endl;
        auto ptr = std::make_unique<Thread>(std::bind(&ThreadPool::threadFunc, this, std::placeholders::_1));
        int tid = ptr->getid();
        threads_.emplace(tid,std::move(ptr));
        threadNum_++;
        threads_[tid]->start();
        idleThreadNum_++;
    }
    return Result(sp);
}


bool ThreadPool::checkRunning()
{
    return isRunning_;
}

void ThreadPool::setMode_(PoolMode mode)
{
    if (checkRunning())
        return;
    poolMode_ = mode;
}

int Thread::threadid = 0;
/*********************************thread��*********************************/
Thread::Thread(threadPoolFunc tpfunc)
    :func_(tpfunc)
    ,id(threadid++)
{}
Thread::~Thread()
{}
void Thread::start()
{
    std::thread t(func_,id);
    t.detach();
}
int Thread::getid()
{
    return id;
}
/*********************************Result��*********************************/
Result::Result(std::shared_ptr<Task> t, bool isValue)
    :task_(t)
    ,isSuccess_(isValue)
{
    task_->setres(this);
}

Any Result::get()
{
    if (isSuccess_)
    {
        sem_.wait();
        return std::move(any_);
    }
    return "";
}

void Result::setVal(Any a)
{

    this->any_ = std::move(a);
    sem_.post();
}


/*********************************Task��*************************************/

Task::Task():res_(nullptr)
{}
Task::~Task() = default;
void Task::myexe()
{
    if (res_ != nullptr)
    {
        res_->setVal(std::move(run()));
    }

}

void Task::setres(Result* res)
{
    res_ = res;
}
